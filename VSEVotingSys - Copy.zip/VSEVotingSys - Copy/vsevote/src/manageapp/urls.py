from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='manage-home'),
    path('results/', views.viewresults, name='manage-viewresults'),
    path('edit/', views.edit, name='manage-edit'),
]
