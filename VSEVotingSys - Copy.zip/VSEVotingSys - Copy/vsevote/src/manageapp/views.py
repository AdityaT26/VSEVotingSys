from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

def home(request):
    return HttpResponse('<h1>Manage-Home</h1>')

def viewresults(request):
    return HttpResponse('<h1>Manage-Results!</h1>')

def edit(request):
    return HttpResponse('<h1>Manage-Edit!</h1>')

@login_required
def adminmanage(*args, **kwargs):
    pass

# Create your views here.
