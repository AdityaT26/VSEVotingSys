from django.shortcuts import render

from django.shortcuts import render, redirect
from django.http import HttpResponse

candidates = [
    {
        'post'   : 'Head Boy',
        'name'   : 'John Doe',
        'grade'  : 10,
        'section': 'A',
        'photo'  : 'photo'
    },
    {
        'post'   : 'Head Girl',
        'name'   : 'Jane Doe',
        'grade'  : 11,
        'section': 'B',
        'photo'  : 'photo'
    },
    {
        'post'   : 'Head Boy',
        'name'   : 'Jason Doe',
        'grade'  : 9,
        'section': 'C',
        'photo'  : 'photo'
    },
]

def home(request):
    posts = []
    for candidate in candidates:
        if candidate['post'] not in posts:
            posts.append(candidate['post'])

    context = {
        'candidates':candidates,
        'posts':posts,
    }
    
    return render(request, 'voterapp/home.html', context)